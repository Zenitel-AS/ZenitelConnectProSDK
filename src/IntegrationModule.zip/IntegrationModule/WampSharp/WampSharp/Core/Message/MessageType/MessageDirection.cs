﻿namespace WampSharp.Core.Message
{
#pragma warning disable 1591
    public enum MessageDirection
    {
        AnyToAny,
        ServerToClient,
        ClientToServer,
    }
#pragma warning restore 1591
}