﻿namespace WampSharp.V2.PubSub
{
    /// <summary>
    /// Represents an id for a subscription to a WAMP topic.
    /// </summary>
    public interface IWampCustomizedSubscriptionId
    {
    }
}