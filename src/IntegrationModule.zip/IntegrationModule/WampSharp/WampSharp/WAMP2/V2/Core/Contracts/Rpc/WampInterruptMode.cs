#pragma warning disable CS1591
namespace WampSharp.V2.Core.Contracts
{
    public static class WampInterruptMode
    {
        public const string Abort = "abort";
        public const string Kill = "kill";
    }
}