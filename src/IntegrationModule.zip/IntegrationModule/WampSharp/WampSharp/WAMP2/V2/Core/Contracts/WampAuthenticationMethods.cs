﻿#pragma warning disable CS1591
namespace WampSharp.V2.Core.Contracts
{
    public static class WampAuthenticationMethods
    {
        public const string WampCra = "wampcra";
        private const string Ticket = "ticket";
    }
}