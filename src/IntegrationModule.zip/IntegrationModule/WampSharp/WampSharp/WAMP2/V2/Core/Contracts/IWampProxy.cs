﻿namespace WampSharp.V2.Core.Contracts
{
    /// <summary>
    /// An interface used for dynamic proxy generator.
    /// </summary>
    public interface IWampProxy
    {
    }
}