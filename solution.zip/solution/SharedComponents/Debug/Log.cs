﻿using ConnectPro.Models;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Threading.Tasks;
using static Wamp.Client.WampClient;

namespace ConnectPro.Debug
{
    public class Log
    {
        private readonly Collections _collections;
        private readonly Events _events;

        private readonly object _lock = new object();
        private readonly ConcurrentDictionary<string, Device> _deviceLookup;

        public Log(Collections collections, Events events)
        {
            _collections = collections ?? throw new ArgumentNullException(nameof(collections));
            _events = events ?? throw new ArgumentNullException(nameof(events));

            _deviceLookup = new ConcurrentDictionary<string, Device>();

            // Initialize the device lookup for faster access
            _events.OnDeviceRetrievalEnd += SetDeviceLookupDictionary;
            _events.OnLogEntryRequested += async (sender, info) => await RecordCallLogAsync(sender, info);
        }

        private void SetDeviceLookupDictionary(object sender, EventArgs e)
        {
            foreach (var device in _collections.RegisteredDevices)
            {
                _deviceLookup.TryAdd(device.dirno, device);
            }
        }

        public async Task RecordCallLogAsync(object sender, object call_info)
        {
            try
            {
                if (_deviceLookup == null || _deviceLookup.Count == 0)
                {
                    throw new InvalidOperationException("No registered devices available.");
                }

                CallLog logEntry = CreateLogEntry(sender, call_info);

                await Task.Run(() => _events.OnLogEntryAdded?.Invoke(this, logEntry));
            }
            catch (Exception ex)
            {
                await Task.Run(() => _events.OnExceptionThrown?.Invoke(this, ex));
            }
        }

        private CallLog CreateLogEntry(object sender, object call_info)
        {
            if (call_info is wamp_call_element wampCallElement)
            {
                var senderDevice = GetDeviceByDirno(wampCallElement.from_dirno);
                return PopulateLogEntry(senderDevice, wampCallElement.from_dirno, wampCallElement.to_dirno,
                                        wampCallElement.to_dirno_current, "Call", wampCallElement.state, wampCallElement.reason);
            }
            else if (call_info is wamp_call_leg_element callLegElement)
            {
                var senderDevice = GetDeviceByDirno(callLegElement.from_dirno);
                return PopulateLogEntry(senderDevice, callLegElement.from_dirno, callLegElement.to_dirno,
                                        "", "Queue", callLegElement.state, callLegElement.reason);
            }
            else if (call_info is CallElement callElement)
            {
                var senderDevice = GetDeviceByDirno(callElement.FromDirno);
                return PopulateLogEntry(senderDevice, callElement.FromDirno, callElement.ToDirno,
                                        callElement.ToDirnoCurrent, "Call", callElement.CallState.ToString(), callElement?.Reason.ToString());
            }
            else
            {
                throw new ArgumentException("Invalid call information object type.", nameof(call_info));
            }
        }

        private Device GetDeviceByDirno(string dirno)
        {
            if (_deviceLookup.TryGetValue(dirno, out var device))
            {
                return device;
            }
            throw new InvalidOperationException($"Device with dirno {dirno} not found.");
        }

        private CallLog PopulateLogEntry(Device senderDevice, string fromDirno, string toDirno, string answeredByDirno, string callType, string state, string reason)
        {
            return new CallLog
            {
                Time = DateTime.UtcNow,
                DeviceName = senderDevice?.name ?? "Unknown Device",
                FromDirno = fromDirno,
                ToDirno = toDirno,
                AnsweredByDirno = answeredByDirno,
                CallType = callType,
                State = GetDescriptiveState(state),
                Reason = reason,
                sender = senderDevice,
                Location = senderDevice?.location ?? "Unknown Location"
            };
        }

        public async Task RecordDoorEventAsync(Device from, Device to)
        {
            try
            {
                var logEntry = new CallLog
                {
                    Time = DateTime.UtcNow,
                    DeviceName = from.name,
                    FromDirno = from.dirno,
                    ToDirno = to.dirno,
                    AnsweredByDirno = to.dirno,
                    CallType = "Call",
                    State = "Door open",
                    Reason = "Door open",
                    sender = from,
                    Location = from.location
                };

                await Task.Run(() => _events.OnLogEntryAdded?.Invoke(this, logEntry));
            }
            catch (Exception ex)
            {
                await Task.Run(() => _events.OnExceptionThrown?.Invoke(this, ex));
            }
        }

        private string GetDescriptiveState(string state)
        {
            switch (state)
            {
                case "in_call":
                    return "In Call";
                case "ringing":
                    return "Ringing";
                case "queued":
                    return "Queued";
                case "ended":
                    return "Ended";
                default:
                    return "Unknown";
            }
        }
    }
}


//using ConnectPro.Models;
//using System;
//using static Wamp.Client.WampClient;

//namespace ConnectPro.Debug
//{
//    public class Log
//    {
//        private Collections _collections;
//        private Events _events;

//        private object _lock = new object();

//        public Log(Collections collections, Events events)
//        {
//            _collections = collections;
//            _events = events;

//            _events.OnLogEntryRequested += RecordCallLog;
//        }

//        public void RecordCallLog(object sender, object call_info)
//        {
//            try
//            {
//                if (_collections.RegisteredDevices == null)
//                {
//                    throw new ArgumentNullException(nameof(_collections.RegisteredDevices));
//                }

//                CallLog logEntry = CreateLogEntry(sender, call_info);

//                _events.OnLogEntryAdded?.Invoke(this, logEntry);
//            }
//            catch (Exception ex)
//            {
//                _events.OnExceptionThrown?.Invoke(this, ex);
//            }
//        }

//        private CallLog CreateLogEntry(object sender, object call_info)
//        {
//            CallLog logEntry = new CallLog();
//            Device senderDevice = null;

//            if (call_info is wamp_call_element wampCallElement)
//            {
//                senderDevice = GetDeviceByDirno(wampCallElement.from_dirno);
//                logEntry = PopulateLogEntry(senderDevice, wampCallElement.from_dirno, wampCallElement.to_dirno,
//                                            wampCallElement.to_dirno_current, "Call", wampCallElement.state, wampCallElement.reason);
//            }
//            else if (call_info is wamp_call_leg_element callLegElement)
//            {
//                senderDevice = GetDeviceByDirno(callLegElement.from_dirno);
//                logEntry = PopulateLogEntry(senderDevice, callLegElement.from_dirno, callLegElement.to_dirno,
//                                            "", "Queue", callLegElement.state, callLegElement.reason);
//            }
//            else if (call_info is CallElement callElement)
//            {
//                senderDevice = GetDeviceByDirno(callElement.FromDirno);
//                logEntry = PopulateLogEntry(senderDevice, callElement.FromDirno, callElement.ToDirno,
//                                            callElement.ToDirnoCurrent, "Call", callElement.CallState?.ToString(), callElement?.Reason.ToString());
//            }
//            else
//            {
//                throw new ArgumentException("Invalid call information object type.", nameof(call_info));
//            }

//            return logEntry;
//        }

//        private Device GetDeviceByDirno(string dirno)
//        {
//            return _collections.RegisteredDevices.Find(x => x.dirno == dirno) ?? throw new InvalidOperationException($"Device with dirno {dirno} not found.");
//        }

//        private CallLog PopulateLogEntry(Device senderDevice, string fromDirno, string toDirno, string answeredByDirno, string callType, string state, string reason)
//        {
//            return new CallLog
//            {
//                Time = DateTime.Now,
//                DeviceName = senderDevice?.name ?? "Unknown Device",
//                FromDirno = fromDirno,
//                ToDirno = toDirno,
//                AnsweredByDirno = answeredByDirno,
//                CallType = callType,
//                State = GetDescriptiveState(state),
//                Reason = reason,
//                sender = senderDevice,
//                Location = senderDevice?.location ?? "Unknown Location"
//            };
//        }

//        public void RecordDoorEvent(Device From, Device To)
//        {
//            try
//            {
//               CallLog logEntry = new CallLog
//                {
//                    Time = DateTime.Now,
//                    DeviceName = From.name,
//                    FromDirno = From.dirno,
//                    ToDirno = To.dirno,
//                    AnsweredByDirno = To.dirno,
//                    CallType = "Call",
//                    State = "Door open",
//                    Reason = "Door open",
//                    sender = From.dirno,
//                    Location = From.location
//                };
//                _events.OnLogEntryAdded?.Invoke(this, logEntry);
//            }
//            catch (Exception exe)
//            {
//                _events.OnExceptionThrown?.Invoke(this, exe);
//            }
//        }

//        private string GetDescriptiveState(string state)
//        {
//            if (state == null)
//                return "";

//            switch (state)
//            {
//                case "in_call": return "In Call";
//                case "ringing": return "Ringing";
//                case "queued": return "Queued";
//                case "ended": return "Ended";
//                default: return "";
//            }
//        }
//    }
//}
