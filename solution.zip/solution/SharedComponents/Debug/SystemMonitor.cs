﻿using System;
using System.Threading.Tasks;
using Wamp.Client;

namespace ConnectPro
{
    public class SystemMonitor
    {
        private object _lock = new object();
        //private Events _events;
        private Configuration _configuration;
        private Tools.ErrorLogger _errorLogger;

        public SystemMonitor(Events events, Configuration configuration)
        {
            //_events = events;
            //_events.OnExceptionThrown += HandleExceptionThrown;
            //_configuration = configuration;
        }

        public SystemMonitor(Events events, Configuration configuration, ref WampClient _wamp)
        {
            //_events = events;
            //_events.OnExceptionThrown += HandleExceptionThrown;
            //_configuration = configuration;
            //_wamp.OnChildLogString += HandleWampChildLogString;
        }
        public void HandleExceptionThrown(object sender, Exception ex)
        {
            lock (_lock)
            {
                using (_errorLogger = new Tools.ErrorLogger(_configuration.ErrorLogFilePath))
                {
                    Task.Run(async () => await _errorLogger.LogMessage(Tools.ErrorLogger.LogLevel.Error, ex.Message, ex));
                }
            }
        }
        private void HandleWampChildLogString(object sender, string ex)
        {
            lock (_lock)
            {
                using (_errorLogger = new Tools.ErrorLogger(_configuration.ErrorLogFilePath))
                {
                    Task.Run(async () => await _errorLogger.LogMessage(Tools.ErrorLogger.LogLevel.Warning, ex));
                }
            }
        }
    }
}
