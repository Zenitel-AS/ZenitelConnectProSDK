﻿using ConnectPro.Models;
using Microsoft.Extensions.Logging.Abstractions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Wamp.Client.WampClient;

namespace ConnectPro.Debug
{
    public class Log
    {
        private Collections _collections;
        private Events _events;
        private Context _context;

        private object _lock = new object();

        public Log(Collections collections, Events events, Context context)
        {
            _collections = collections;
            _events = events;
            _context = context;

            _events.OnLogEntryRequested += RecordCallLog;
        }


        /// <summary>
        /// Records a new call log entry to the collection.
        /// </summary>
        /// <param name="sender">The object that triggered the loging event</param>
        /// <param name="call_info">The object containing iformation for the log entry, either a <see cref="wamp_call_element"/> or a <see cref="wamp_call_leg_element"/> object.</param>
        public void RecordCallLog(object sender, object call_info)
        {
            CallLog logEntry = null;

            try
            {
                if (_collections.RegisteredDevices == null)
                {
                    throw new ArgumentNullException(nameof(_collections.RegisteredDevices));
                }

                if (_context == null)
                {
                    throw new ArgumentNullException(nameof(_context));
                }

                if (call_info is wamp_call_element callElement)
                {
                    var senderDevice = _collections.RegisteredDevices.Find(x => x.dirno == callElement.from_dirno);
                    if (senderDevice == null)
                    {
                        throw new InvalidOperationException("Sender device not found in device list");
                    }

                    logEntry = new CallLog
                    {
                        Time = DateTime.Now,
                        DeviceName = senderDevice.name,
                        FromDirno = callElement.from_dirno,
                        ToDirno = callElement.to_dirno,
                        AnsweredByDirno = callElement.to_dirno_current,
                        CallType = "call",
                        State = callElement.state,
                        Reason = callElement.reason,
                        sender = senderDevice,
                        Location = senderDevice.location
                    };
                }
                else if (call_info is wamp_call_leg_element callLegElement)
                {
                    var senderDevice = _collections.RegisteredDevices.Find(x => x.dirno == callLegElement.from_dirno);

                    logEntry = new CallLog
                    {
                        Time = DateTime.Now,
                        DeviceName = senderDevice?.name,
                        FromDirno = callLegElement.from_dirno,
                        ToDirno = callLegElement.to_dirno,
                        CallType = "queue",
                        AnsweredByDirno = "",
                        State = callLegElement.state,
                        Reason = callLegElement.reason,
                        sender = senderDevice,
                        Location = senderDevice?.location
                    };
                }
                else
                {
                    throw new ArgumentException("Invalid sender type, expected wamp_call_element or wamp_call_leg_element", nameof(sender));
                }

                lock (_lock)
                {
                    List<CallLog> dbList = _context.CallLogs.ToList();

                    bool entryExists = dbList.Any(x => x.FromDirno == logEntry.FromDirno
                                && x.ToDirno == logEntry.ToDirno
                                && x.CallType == logEntry.CallType
                                && x.State == logEntry.State
                                && x.Reason == logEntry.Reason
                                && x.AnsweredByDirno == logEntry.AnsweredByDirno
                                && Math.Abs((x.Time - logEntry.Time).TotalSeconds) < 1);

                    if (!entryExists)
                    {
                        _context.CallLogs.Add(logEntry);
                        _context.SaveChanges();
                    }
                }

                _events.OnLogEntryAdded?.Invoke(this, logEntry);
            }
            catch (Exception exe)
            {
                _events.OnExceptionThrown?.Invoke(this, exe);
            }
        }
    }
}
