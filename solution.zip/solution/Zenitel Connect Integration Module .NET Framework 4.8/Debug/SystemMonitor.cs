﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConnectPro
{
    public class SystemMonitor
    {
        private Events _events;
        private Configuration _configuration;
        private Tools.ErrorLogger _errorLogger;

        public SystemMonitor(Events events, Configuration configuration)
        {
            _events = events;
            _events.OnExceptionThrown += HandleExceptionThrown;
            _configuration = configuration;
        }
        public void HandleExceptionThrown(object sender, Exception ex)
        {
            if (_errorLogger == null)
                _errorLogger = new Tools.ErrorLogger(_configuration.ErrorLogFilePath);

            string message = ex.ToString();
            Task.Run(async () => await _errorLogger.LogMessage(Tools.ErrorLogger.LogLevel.Error, message, ex));
        }
    }
}
